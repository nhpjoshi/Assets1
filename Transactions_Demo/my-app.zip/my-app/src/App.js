import React, { useState, useEffect } from "react";
import "./App.css";

const App = () => {
  const [logs, setLogs] = useState([]);
  const [primaryData, setPrimaryData] = useState("No Data");
  const [secondaryData, setSecondaryData] = useState("No Data");
  const [inputText, setInputText] = useState("");
  useEffect(() => {
    localStorage.removeItem("logs"); // Remove stored logs on reload
    setLogs([]); // Clear logs in state
  }, []);
  

  const handleInitiateTransaction = async () => {
    try {
      setLogs([]);
      const response = await fetch("http://localhost:5022/initiate-transaction", { method: "POST" });
      const data = await response.json();
      
      const newLogs = data.logs || ["Transaction started"];
      setLogs(newLogs);
      setInputText(newLogs.join("\n")); // Populate logs in input text area
      
      if (data.primaryData) {
        setPrimaryData(`Balance: ${data.primaryData.balance}`);
      } else {
        setPrimaryData("Balance: 100");
      }
    } catch (error) {
      setLogs(["Error initiating transaction"]);
      setInputText("Error initiating transaction");
    }
  };

  const handleUpdateTo200 = async () => {
    try {
      const response = await fetch("http://localhost:5022/update-to-200", { method: "POST" });
      const data = await response.json();
      
      const newLogs = data.logs || ["Balance updated to 200"];
      setLogs(newLogs);
      setInputText(newLogs.join("\n"));
      
      if (data.primaryData) {
        setPrimaryData(`Balance: ${data.primaryData.balance}`);
      } else {
        setPrimaryData("Balance: 200");
      }
    } catch (error) {
      setLogs(["Error updating balance"]);
      setInputText("Error updating balance");
    }
  };

  const handleCommitTransaction = async () => {
    try {
      const response = await fetch("http://localhost:5022/commit-transaction", { method: "POST" });
      const data = await response.json();
      
      const newLogs = data.logs || ["Transaction committed"];
      setLogs(newLogs);
      setInputText(newLogs.join("\n"));
      
      if (data.secondaryData) {
        setSecondaryData(`Balance: ${data.secondaryData.balance}`);
      } else {
        setSecondaryData("Balance: 200");
      }
    } catch (error) {
      setLogs(["Error committing transaction"]);
      setInputText("Error committing transaction");
    }
  };

  return (
    <div className="container">
      <div className="card">
        {/* Left Section - Input and Buttons */}
        <div className="left-section">
          <textarea className="input-text" value={inputText} readOnly placeholder="Transaction Logs"></textarea>
          <div className="button-group">
            <button className="initiate-button" onClick={handleInitiateTransaction}>
              Initiate Transaction
            </button>
            <button className="update-button" onClick={handleUpdateTo200}>
              Update to 200
            </button>
            <button className="commit-button" onClick={handleCommitTransaction}>
              Commit
            </button>
          </div>
        </div>

        <div className="isolation-info">
          <strong>Isolation:</strong> Snapshot , <strong>Write:</strong> Majority <br />
          Purpose of this demo is to show the capability of MongoDB transactions, ensuring Consistency and Isolation.
        </div>

        {/* Right Section - Text Areas */}
        <div className="right-section">
          <div className="text-area-group">
            <label className="label">Primary</label>
            <textarea className="text-area" readOnly value={primaryData}></textarea>
          </div>
          <div className="text-area-group">
            <label className="label">Secondary</label>
            <textarea className="text-area" readOnly value={secondaryData}></textarea>
          </div>
          <div className="text-area-group">
            <label className="label">Secondary</label>
            <textarea className="text-area" readOnly value={secondaryData}></textarea>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
